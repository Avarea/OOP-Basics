﻿public enum StatType
{
    Endurance,
    Sprint,
    Dribble,
    Passing,
    Shooting
}