﻿namespace BashSoft
{
    using BashSoft.Static_data;

    class Launcher
    {
        static void Main()
        {
            Welcome.Message();
            InputReader.StartReadingCommands();
        }
    }
}
