﻿namespace DungeonsAndCodeWizards.Models.Interfaces
{
    public interface IAttackable
    {
        void Attack(Character character);
    }
}
