﻿public class EarthNation : Nation
{
    public EarthNation()
        : base("Earth")
    {
    }
}