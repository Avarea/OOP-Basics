﻿public class AirNation : Nation
{
    public AirNation()
        : base("Air")
    {
    }
}