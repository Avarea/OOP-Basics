﻿public class WaterNation : Nation
{
    public WaterNation()
        : base("Water")
    {
    }
}