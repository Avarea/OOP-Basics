﻿public class FireNation : Nation
{
    public FireNation()
        : base("Fire")
    {
    }
}