﻿public enum DiscountEnum
{
    None = 0,
    SecondVisit = 10,
    VIP = 20,
}
